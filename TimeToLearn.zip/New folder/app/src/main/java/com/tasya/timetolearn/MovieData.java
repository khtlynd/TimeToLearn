package com.tasya.timetolearn;

public class MovieData {
    //attribute
    String name;
    String image_url;
    String year;

    //constructor
    MovieData (String name, String iamge_url, String year) {
        this.name = name;
        this.image_url = image_url;
        this.year = year;
    }
}
